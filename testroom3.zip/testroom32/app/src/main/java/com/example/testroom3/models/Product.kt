package com.example.testroom3.models

data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val price: Int, // Prix en MAD
    val imageRes: Int
)