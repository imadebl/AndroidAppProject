package com.example.testroom3.viewmodels

import androidx.lifecycle.ViewModel
import com.example.testroom3.models.Product
import com.example.testroom3.models.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class MainViewModel : ViewModel() {
    // Panier
    private val _cartItems = MutableStateFlow<List<Product>>(emptyList())
    val cartItems = _cartItems.asStateFlow()

    fun addToCart(product: Product) {
        _cartItems.update { currentList -> currentList + product }
    }
    fun removeFromCart(product: Product) {
        _cartItems.update { currentList -> currentList - product }
    }
    fun getTotalPrice(): Int {
        return _cartItems.value.sumOf { it.price }
    }

    // Profil
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile = _userProfile.asStateFlow()

    fun updateUser(name: String, email: String, phone: String, address: String) {
        _userProfile.update { it.copy(name = name, email = email, phone = phone, address = address) }
    }
}