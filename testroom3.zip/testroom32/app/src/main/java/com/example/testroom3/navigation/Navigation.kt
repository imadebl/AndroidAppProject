package com.example.testroom3.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.testroom3.models.allProducts
import com.example.testroom3.screens.*
import com.example.testroom3.viewmodels.MainViewModel

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "welcome_screen") {
        composable("welcome_screen") { WelcomeScreen { navController.navigate("login_screen") } }
        composable("login_screen") { LoginScreen({ navController.navigate("home_screen") }, { navController.navigate("signup_screen") }) }
        composable("signup_screen") { SignupScreen({ navController.navigate("home_screen") }, { navController.popBackStack() }) }
        composable("home_screen") { HomeScreen(navController) }
        composable("category_screen") { CategoryScreen(navController) }
        composable(
            route = "product_list/{categoryName}",
            arguments = listOf(navArgument("categoryName") { type = NavType.StringType })
        ) { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("categoryName") ?: "All"
            ProductListScreen(navController, categoryName)
        }
        composable("profile_screen") { ProfileScreen(navController, viewModel) }
        composable("edit_profile_screen") { EditProfileScreen(navController, viewModel) }
        composable(
            route = "detail_screen/{productId}",
            arguments = listOf(navArgument("productId") { type = NavType.IntType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getInt("productId") ?: 0
            val product = allProducts.find { it.id == productId }
            if (product != null) {
                ProductDetailScreen(
                    product = product,
                    onBack = { navController.popBackStack() },
                    onAddToCart = {
                        viewModel.addToCart(product)
                        navController.navigate("cart_screen")
                    }
                )
            }
        }
        composable("cart_screen") { CartScreen(navController, viewModel) }
    }
}

@Composable
fun BottomNavBar(navController: NavController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    NavigationBar(containerColor = Color.White) {
        NavigationBarItem(selected = currentRoute == "home_screen", onClick = { navController.navigate("home_screen") }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Accueil") })
        NavigationBarItem(selected = currentRoute == "category_screen", onClick = { navController.navigate("category_screen") }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Catégorie") })
        NavigationBarItem(selected = currentRoute == "cart_screen", onClick = { navController.navigate("cart_screen") }, icon = { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("Panier") })
        NavigationBarItem(selected = currentRoute == "profile_screen", onClick = { navController.navigate("profile_screen") }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profil") })
    }
}