package com.example.testroom3.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack

import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.testroom3.models.Product
import com.example.testroom3.models.allProducts
import com.example.testroom3.navigation.BottomNavBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(Color.White).padding(16.dp)) {
                Text("Marché Sport", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = "", onValueChange = {}, enabled = false,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("Rechercher...") },
                    modifier = Modifier.fillMaxWidth()
                        .clickable { navController.navigate("product_list/All") }
                        .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp)),
                    colors = OutlinedTextFieldDefaults.colors(disabledContainerColor = Color(0xFFF5F5F5), disabledBorderColor = Color.Transparent)
                )
            }
        },
        bottomBar = { BottomNavBar(navController) }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).padding(horizontal = 16.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F)), modifier = Modifier.fillMaxWidth().height(160.dp)) {
                    Box {
                        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha=0.3f)))
                        Column(modifier = Modifier.padding(16.dp).align(Alignment.CenterStart)) {
                            Text("-30%", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                            Text("Offre spéciale hiver", color = Color.White)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
            item {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Nouveautés", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Voir tout", color = Color(0xFF009688), fontWeight = FontWeight.Bold, modifier = Modifier.clickable { navController.navigate("product_list/All") })
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    allProducts.take(2).forEach {
                        ProductCardSimple(it) { navController.navigate("detail_screen/${it.id}") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryScreen(navController: NavController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Catégories") }) }, bottomBar = { BottomNavBar(navController) }) { padding ->
        val categories = listOf("Ballons", "Chaussures", "Gants", "Sacs", "Protection", "Vêtements")
        val colors = listOf(Color(0xFFFFCC80), Color(0xFF80CBC4), Color(0xFF90CAF9), Color(0xFFCE93D8), Color(0xFFEF9A9A), Color(0xFFA5D6A7))
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(padding)) {
            items(categories.size) { index ->
                Card(modifier = Modifier.height(120.dp).clickable { navController.navigate("product_list/${categories[index]}") }, colors = CardDefaults.cardColors(containerColor = colors[index])) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(categories[index], fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductListScreen(navController: NavController, categoryFilter: String) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredProducts = allProducts.filter { product -> (categoryFilter == "All" || product.category == categoryFilter) && product.name.contains(searchQuery, ignoreCase = true) }
    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(Color.White)) {
                TopAppBar(
                    title = { Text(if (categoryFilter == "All") "Tous les produits" else categoryFilter) },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            // --- CORRECTION ICI (Default au lieu de AutoMirrored) ---
                            Icon(Icons.Default.ArrowBack, contentDescription = null)
                        }
                    }
                )
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher...") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp)),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent
                    )
                )
            }
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(padding)
        ) {
            items(filteredProducts) { product ->
                ProductCardSimple(product) {
                    navController.navigate("detail_screen/${product.id}")
                }
            }
        }
    }
}

@Composable
fun ProductCardSimple(product: Product, onClick: () -> Unit) {
    Card(modifier = Modifier.width(165.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
            Image(
                painter = painterResource(id = product.imageRes),
                contentDescription = product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(8.dp)).background(Color.LightGray)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(product.name, fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 14.sp)
            Text("${product.price} MAD", color = Color(0xFFDAA520), fontWeight = FontWeight.Bold)
        }
    }
}