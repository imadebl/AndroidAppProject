package com.example.testroom3.models

data class UserProfile(
    val name: String = "Mohamed Amine",
    val email: String = "mohamed@email.com",
    val phone: String = "06 12 34 56 78",
    val address: String = "Casablanca, Maroc"
)