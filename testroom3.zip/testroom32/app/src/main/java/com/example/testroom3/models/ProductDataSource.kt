package com.example.testroom3.models

import com.example.testroom3.R

// Liste simulée des produits
val allProducts = listOf(
    // Ballons
    Product(1, "Ballon First Kick", "Ballons", 49, R.drawable.imad1),
    Product(2, "Ballon Pro Ligue", "Ballons", 199, R.drawable.imad2),
    // Chaussures
    Product(3, "RunStyle 500", "Chaussures", 249, R.drawable.imad3),
    Product(4, "Kipsta Agility", "Chaussures", 399, R.drawable.imad4),
    // Gants
    Product(5, "Gants Gardien", "Gants", 120, R.drawable.imad5),
    Product(6, "Gants Boxe", "Gants", 80, R.drawable.imad6),
    // Sacs
    Product(7, "Sac à dos 20L", "Sacs", 99, R.drawable.imad7),
    Product(8, "Sac de sport", "Sacs", 159, R.drawable.imad8),
    // Protection
    Product(9, "Protège-tibias", "Protection", 45, R.drawable.imad9),
    Product(10, "Casque Vélo", "Protection", 250, R.drawable.imad10),
    // Vêtements
    Product(11, "Maillot Sport", "Vêtements", 79, R.drawable.imad11),
    Product(12, "Short Running", "Vêtements", 59, R.drawable.imad12)
)